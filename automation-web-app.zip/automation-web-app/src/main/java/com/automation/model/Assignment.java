package com.automation.model;

public class Assignment {

    private int id;
    private String testCaseNumber;
    private String assignedUser;
    private String assignedDate;

    public Assignment() {
    }

    public Assignment(int id, String testCaseNumber, String assignedUser, String assignedDate) {
        this.id = id;
        this.testCaseNumber = testCaseNumber;
        this.assignedUser = assignedUser;
        this.assignedDate = assignedDate;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTestCaseNumber() {
        return testCaseNumber;
    }

    public void setTestCaseNumber(String testCaseNumber) {
        this.testCaseNumber = testCaseNumber;
    }

    public String getAssignedUser() {
        return assignedUser;
    }

    public void setAssignedUser(String assignedUser) {
        this.assignedUser = assignedUser;
    }

    public String getAssignedDate() {
        return assignedDate;
    }

    public void setAssignedDate(String assignedDate) {
        this.assignedDate = assignedDate;
    }
}