package com.automation.servlet;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.automation.model.Assignment;
import com.automation.util.DBConfig;

public class AssignmentDAO {

    private DBConfig dbConfig;

    public AssignmentDAO() {
        dbConfig = new DBConfig();
    }

    public boolean saveAssignment(Assignment assignment) {

        boolean status = false;

        String procedure = "{CALL InsertTestCaseAssignment(?,?)}";

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con = DriverManager.getConnection(
                    dbConfig.getUrl(),
                    dbConfig.getUsername(),
                    dbConfig.getPassword());

            CallableStatement cs = con.prepareCall(procedure);

            cs.setString(1, assignment.getTestCaseNumber());

            cs.setString(2, assignment.getAssignedUser());

            int rows = cs.executeUpdate();

            if (rows > 0) {
                status = true;
            }

            cs.close();
            con.close();

        } catch (SQLException e) {

            System.out.println(e.getMessage());

        } catch (ClassNotFoundException e) {

            e.printStackTrace();

        }

        return status;

    }

}